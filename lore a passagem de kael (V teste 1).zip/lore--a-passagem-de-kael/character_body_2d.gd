extends CharacterBody2D

const SPEED = 300.0
const RUN_SPEED = 500.0
const JUMP_VELOCITY = -900.0

@export var move_speed: float = 150.0

var estava_no_ar: bool = false

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta

	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY
		$AnimatedSprite2D.play("pulo")

	var direction := Input.get_axis("ui_left", "ui_right")
	var is_running := Input.is_action_pressed("corrida")
	var current_speed := RUN_SPEED if is_running else SPEED

	if direction:
		velocity.x = direction * current_speed
		$AnimatedSprite2D.flip_h = direction < 0
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()

	if not is_on_floor():
		$AnimatedSprite2D.play("pulo")
	elif direction:
		$AnimatedSprite2D.play("andar")
	else:
		$AnimatedSprite2D.play("pare")

	estava_no_ar = not is_on_floor()
