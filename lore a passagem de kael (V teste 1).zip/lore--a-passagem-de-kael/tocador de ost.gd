extends AudioStreamPlayer

func _ready():
		stream = preload("res://OST/tunel do fim let there be light 2 inferno of the vengeful one.mp3")
		volume_db = 0
		finished.connect(_on_finished)
		play()
					
func _on_finished():
	play()
